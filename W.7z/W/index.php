<?php
$conn = mysqli_connect('localhost', 'root', '', 'wędkarstwo');
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="w.css">
</head>
<body>
    <div id="baner">
        <h2>WĘDKARSTWO</h2>
        WĘDKARSTWO
</div>
<div id="lewy">
        <h2>Szupak</h2>
        <p aling=left><img src=yu alt=Szupak></p>
        <?php
    $zapytanie1 = "SELECT id,nazwa,wystepowanie FROM ryby WHERE styl_zycia=1";
    $zapytanie1 = mysqli_query($conn, $zapytanie1);
    if ($zapytanie1) {
        while ($row = mysqli_fetch_assoc($zapytanie1)) {
            echo '<li>' . $row['id'] . ' ' . $row['nazwa'] . ' ' . $row['wystepowanie'] . ' ' .'</li>';
        }
    } else {
        echo "Błąd zapytania: " . mysqli_error($conn);
    }
    ?>
</div>
<div id="środek">
        <h2>Lin</h2>
        <p aling=center><img src=lin.jfif alt=Lin></p>
        <?php
    $zapytanie2 = "SELECT akwen,wojewodztwo from lowisko WHERE rodzaj=2 OR rodzaj=3";
    $zapytanie2 = mysqli_query($conn, $zapytanie2);
    if ($zapytanie2) {
        while ($row = mysqli_fetch_assoc($zapytanie2)) {
            echo '<li>' . $row['akwen'] . ' ' . $row['wojewodztwo'] .  ' ' .'</li>';
        }
    } else {
        echo "Błąd zapytania: " . mysqli_error($conn);
    }
    ?>
</div>
<div id="prawy">
        <h2>Karp</h2>
       <p aling=right> <img src=karp.jpg alt=Karp></p>
        <?php
    $zapytanie3 = "SELECT nazwa FROM ryby WHERE styl_zycia=1";
    $zapytanie3 = mysqli_query($conn, $zapytanie3);
    if ($zapytanie2) {
        while ($row = mysqli_fetch_assoc($zapytanie3)) {
            echo '<li>' . $row['nazwa'] .  ' ' .'</li>';
        }
    } else {
        echo "Błąd zapytania: " . mysqli_error($conn);
    }
    ?>
</div>
<div id=stopka>
        <h2>Dane</h2>
        Autor:Jan Kowalski  
        <a href=kwerendy.txt> Kwerendy</a>
            

</div>
</body>
</html>