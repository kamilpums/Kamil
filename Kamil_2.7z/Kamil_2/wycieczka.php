<?php
	    $conn = new mysqli("localhost","root","","egzamin3");
	?>
	
	<!DOCTYPE html>
	<html lang="pl">
	    <head>
	        <meta charset="UTF-8">
	        <meta http-equiv="X-UA-Compatible" content="IE=edge">
	        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	        <title>Wycieczki krajoznawcze</title>
	        <link rel="stylesheet" href=".css">
        </head>
        <body>
	       <div id=góra>
         <header>
            <h1>WITAMY W BIURZE PODRÓŻY</h1>
        </header>               
            </div>
            <div id=lewy>
                <h2>Kontakt</h2> gvyt
            </div>
            <div id=środek>
            <h2>Galeria</h2>
            </div>
            <div id=prawy>
            <h2>Promocja</h2>
            </div>
            <div id=dół>

            </div>
            <footer>
                Kamil Strzelecki    
            </footer>    

        </body>
        </html>
